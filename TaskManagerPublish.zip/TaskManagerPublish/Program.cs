﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
namespace TaskManager
{

    #region Task Manager class Library
    /// <summary>
    /// Class containing the list of processes and methods to add,list,sort and kill 
    /// </summary>
    class TaskManager
    {

        //List of operating system processes
        private static OperatingSystemProcess[] listOfProcesses;
        //Max number of permissible processes to be read from resource file.
        private static int maxCapacity = 0;
        //Indicator to infer whether the process list is initialized with the capacity. True if initialized.
        private static bool initialized = false;
        /// <summary>
        /// Method to add a process in the listOfProcesses. By making a dummy call to OperatingSystemWrapper and checking the status.
        /// </summary>
        /// <param name="priority">The priority of new process to be created. Only permissible values are the members of the Enum - Priority</param>
        /// <returns>The status based on dummy OS wrapper call and max capacity in case of overflow</returns>
        public static Status AddProcess(Priority priority)
        {
            //return invalid capacity status if listOfProcesses is not initialized. 
            if (!initialized)
            {
                return Status.InvalidCapacity;
            }
            Status status = Status.Overflow;
            //iterate through the listOfProcesses
            for (int iterator = 0; iterator < listOfProcesses.Length; iterator++)
            {
                //null value means the array location at the index iterator is available to store the new process
                if (listOfProcesses[iterator] == null)
                {
                    //Dummy call to OS wrapper returns true / false. Currently just returns true.
                    if (OperatingSystemWrapper.AddProcess())
                    {
                        //Create new object of OperatingSystemProcess class and provide priority and latest unique identifier from the UniqueIdentifier method call.
                        OperatingSystemProcess process = new OperatingSystemProcess(priority, UniqueIdentifier.GetLastIdentifier());

                        //Add the process to the iterator'th index
                        listOfProcesses[iterator] = process;

                        //Increment the unique identifier for next turn.
                        UniqueIdentifier.Increment();

                        status = Status.Success;

                        //added the new process object to a free location. No need to further iterate.
                        break;
                    }
                    else
                        //If OS wrapper fails to add process.
                        status = Status.Error;
                }

            }
            //return the status 
            return status;
        }

        /// <summary>
        /// Method to initialize the listOfProcesses Array. Based on the capacity provided in configuration.
        /// </summary>
        /// <param name="capacityConfig">Value of Capacity in resource file</param>
        /// <returns>Returns results based on the provided capacity</returns>
        public static Status Initialize(string capacityConfig)
        {
            //Initialize the capacity of the process array.
            int capacity = 0;
            //Try to convert the config value into integer
            if (int.TryParse(capacityConfig, out capacity) && capacity > 0)
            {
                try
                {
                    //Initialize the listOfProcesses with the provided capacity
                    listOfProcesses = new OperatingSystemProcess[capacity];
                    //Initialize the static class level variable with the capacity
                    maxCapacity = capacity;
                    //Set flag to true for initialization checks.
                    initialized = true;
                }
                catch (System.OutOfMemoryException ex)
                {
                    //The capacity of Array exceeded.
                    return Status.Overflow;
                }
                return Status.Success;
            }
            else
            {
                //Invalid value for a capacity. Ex. Non numeric value.
                return Status.InvalidCapacity;
            }
        }

        /// <summary>
        /// Call the AddProcess, if overflow sorts the existing processes kills the oldest on and puts the new process at that index.
        /// </summary>
        /// <param name="priority">Priority of the new process</param>
        /// <returns>Returns the status of the add operation</returns>
        public static Status AddProcessFirstInFirstOut(Priority priority)
        {
            //Try to add process in normal manner.
            Status status = AddProcess(priority);
            //if no capacity
            if (status == Status.Overflow)
            {
                //Sort the existing processes on creation time in ascending order - oldest process first
                OperatingSystemProcess[] processList = SortProcesses(SortBasis.CreationTime, SortOrder.Ascending);
                if (processList[0] != null)
                {
                    //Kill the first process in the sorted list which must be the oldest one. By proving the process id.
                    Status killStatus = KillProcess(processList[0].ProcessID);

                    if (killStatus == Status.Success)
                    {
                        //if the kill is successful then add the new process at the newly vacated index and return the status.
                        status = AddProcess(priority);
                        return status;
                    }
                }
            }
            //return status
            return status;
        }

        /// <summary>
        /// Call the AddProcess, if overflow, sorts the existing processes and kills the lowest priority one. If no low prio process then no change.
        /// </summary>
        /// <param name="priority">Priority of the new process</param>
        /// <returns>Returns the status </returns>
        public static Status AddProcessHigherPriority(Priority priority)
        {
            //Try to add process in normal manner.
            Status status = AddProcess(priority);
            //If no capacty
            if (status == Status.Overflow)
            {
                //Sort on the basis of priority lowest at the top
                OperatingSystemProcess[] processList = SortProcesses(SortBasis.Priority, SortOrder.Ascending);
                if (processList[0] != null)
                {
                    //Get the lowest priority process
                    Priority lowestPriority = processList[0].ProcessPriority;
                    //If the new candidate process has lower priority than the existing lowest priority process then report overflow
                    if (PrioritiesComparer.Compare(priority, lowestPriority) <= 0)
                    {
                        return Status.Overflow;
                    }
                    //List to hold existing similar priority processes
                    OperatingSystemProcess[] similarPriorityList = new OperatingSystemProcess[processList.Length];
                    int index = 0;
                    //fill the list with similar priority processes
                    for (int iterator = 0; iterator < processList.Length; iterator++)
                    {
                        if (processList[iterator] != null)
                        {
                            if (processList[iterator].ProcessPriority == lowestPriority)
                            {
                                similarPriorityList[index] = processList[iterator];
                                index++;
                            }
                        }
                    }
                    ProcessComparerByDateAsc comparer = new ProcessComparerByDateAsc();
                    //Sort the similar priority processes oldest first
                    Array.Sort(similarPriorityList, comparer);

                    if (similarPriorityList[0] != null)
                    {
                        //Kill the first process in the list which is naturally the oldest low priority process
                        Status killStatus = KillProcess(similarPriorityList[0].ProcessID);
                        if (killStatus == Status.Success)
                        {
                            //Add the new process at the place of the killed process
                            status = AddProcess(priority);
                            return status;
                        }

                    }


                }

            }
            //return the default status if unchanged.
            return status;

        }
        /// <summary>
        /// List the process and return an array of processes
        /// </summary>
        /// <returns>Array of existing processes</returns>
        public static OperatingSystemProcess[] ListProcess()
        {
            //Index for output array
            int index = 0;
            //output array
            OperatingSystemProcess[] outputlistOfProcesses = new OperatingSystemProcess[maxCapacity];

            //Iterate till max capacity
            while (index < maxCapacity)//
            {
                //if the list is initialiez and the index position is non null then add the index value in the output array.
                if (initialized && listOfProcesses[index] != null)
                {
                    outputlistOfProcesses[index] = listOfProcesses[index];

                }
                //increment the index for next time.
                index++;
            }
            //Return the list of processes.
            return outputlistOfProcesses;

        }

        /// <summary>
        /// Sort process on the basis and order
        /// </summary>
        /// <param name="basis">Identifier,Priority or creation time</param>
        /// <param name="order">Ascending or Descending</param>
        /// <returns>return the sorted list of processes</returns>
        public static OperatingSystemProcess[] SortProcesses(SortBasis basis, SortOrder order)//string sortBasis
        {
            //Get the process list
            OperatingSystemProcess[] processList = TaskManager.ListProcess();

            //Selector
            switch (basis)
            {
                case SortBasis.Priority:
                    if (order == SortOrder.Ascending)
                    {
                        //Create the instance of custom priority comparer low priority top.
                        ProcessCompareByPriorityAsc priorityComparer = new ProcessCompareByPriorityAsc();

                        //Sort the process list with the custom comparer using C# default Array sort method.
                        Array.Sort(processList, priorityComparer);
                    }
                    else
                    {
                        //Create the instance of custom priority comparer high priority top.
                        ProcessCompareByPriorityDesc priorityComparer = new ProcessCompareByPriorityDesc();
                        //Sort the process list with the custom comparer using C# default Array sort method.
                        Array.Sort(processList, priorityComparer);

                    }
                    break;
                case SortBasis.CreationTime:
                    if (order == SortOrder.Ascending)
                    {
                        //Create the instance of custom date comparer oldest process top
                        ProcessComparerByDateAsc priorityComparer = new ProcessComparerByDateAsc();
                        //Sort the process list with the custom comparer using C# default Array sort method.
                        Array.Sort(processList, priorityComparer);
                    }
                    else
                    {
                        //Create the instance of custom date comparer newest process top
                        ProcessComparerByDateDesc priorityComparer = new ProcessComparerByDateDesc();
                        //Sort the process list with the custom comparer using C# default Array sort method.
                        Array.Sort(processList, priorityComparer);

                    }

                    break;
                case SortBasis.Identifier:
                    if (order == SortOrder.Ascending)
                    {
                        //Create the instance of custom date comparer lowest rank identifier top
                        ProcessComparerByIdentifierAsc priorityComparer = new ProcessComparerByIdentifierAsc();
                        //Sort the process list with the custom comparer using C# default Array sort method.
                        Array.Sort(processList, priorityComparer);
                    }
                    else
                    {
                        //Create the instance of custom date comparer higest rank identifier top
                        ProcessComparerByIdentifierDesc priorityComparer = new ProcessComparerByIdentifierDesc();
                        //Sort the process list with the custom comparer using C# default Array sort method.
                        Array.Sort(processList, priorityComparer);

                    }
                    //exit the selector
                    break;


            }
            //return the sorted list/
            return processList;
        }

        /// <summary>
        /// Calls the dummy OS wrapper Kill process thread safe way and removes the process from the processList.
        /// </summary>
        /// <param name="id">Identification of the process to be removed.</param>
        /// <returns>Kill status</returns>
        public static Status KillProcess(int id)
        {
            //If not initialized means process List is not initialzed because of invalid capacity specified.
            if (!initialized)
            {
                return Status.InvalidCapacity;
            }


            //Check if the identifier exists
            if (IsValidIdentifier(id))
            {
                //Define lock for thread safety
                object processLock = new object();
                //Lock the process during the delete operation.
                lock (processLock)
                {
                    //If the OS wrapper could indeed delete the process
                    if (OperatingSystemWrapper.DeleteProcess())
                    {
                        //Iterate through the list of processes and set to null the value at the index to be deleted.
                        for (int iterator = 0; iterator < listOfProcesses.Length; iterator++)
                        {
                            if (listOfProcesses[iterator] != null && listOfProcesses[iterator].ProcessID == id)
                            {
                                listOfProcesses[iterator] = null;
                            }
                        }
                        return Status.Success;
                    }
                    else
                    {
                        //OS wrapper returns false.
                        return Status.Error;
                    }
                }

            }
            //if the identifier to be deleted is not valid.
            return Status.Invalid;
        }
        /// <summary>
        /// Iteratively calls the kill process for all processes
        /// </summary>
        /// <returns>Collective status of all processes</returns>
        public static Status KillAllProcesses()
        {
            //An initialized process list in required
            if (!initialized)
            {
                return Status.InvalidCapacity;
            }
            //If there are no processes to delete.
            if (GetListLength() == 0)
            {
                return Status.NoOperation;
            }
            //Hold status of each killed process.
            Status[] statusList = new Status[listOfProcesses.Length];
            for (int iterator = 0; iterator < listOfProcesses.Length; iterator++)
            {

                if (listOfProcesses[iterator] != null)
                    statusList[iterator] = KillProcess(listOfProcesses[iterator].ProcessID);
            }
            for (int iterator = 0; iterator < statusList.Length; iterator++)
            {
                //if any one of the deleted process had an error from OS wrapper then return the status of Kill all operation as Error.
                if (statusList[iterator] == Status.Error)
                {
                    return Status.Error;
                }
            }
            //Till this point no error means success.
            return Status.Success;
        }

        /// <summary>
        /// Kill Process iteratively belonging to a particular priority.
        /// </summary>
        /// <param name="priority">The priority of the processes to be deleted.</param>
        /// <returns>Collective kill status</returns>
        public static Status KillProcess(Priority priority)
        {
            //Initialized list of processes in required.
            if (!initialized)
            {
                return Status.InvalidCapacity;
            }
            //Hold identifiers of processes with same priority.
            int[] identifiers = new int[listOfProcesses.Length];

            //Index for identifiers array
            int index = 0;
            //status of each kill action.
            Status[] statusList = new Status[listOfProcesses.Length];
            //iterate and identify the processes having the priority to be deleted.
            for (int iterator = 0; iterator < listOfProcesses.Length; iterator++)
            {
                if (listOfProcesses[iterator] != null && listOfProcesses[iterator].ProcessPriority == priority)
                {
                    //populate the identifiers array
                    identifiers[index] = listOfProcesses[iterator].ProcessID;
                    index++;
                }
            }
            //iterate the identifiers list and call the Kill Process on each
            for (int iterator = 0; iterator < identifiers.Length; iterator++)
            {
                //zero value at identifier means no valid identifier
                if (identifiers[iterator] != 0)
                {
                    //call kill and record the status
                    statusList[iterator] = KillProcess(identifiers[iterator]);
                }
            }
            //if any one status is Error then the Kill operition fails resulting error. Not implemented for process specific errors. Partial kill is possible.
            for (int iterator = 0; iterator < statusList.Length; iterator++)
            {
                if (statusList[iterator] == Status.Error)
                {
                    return Status.Error;
                }
            }
            //If there then its success.
            return Status.Success;

        }
        /// <summary>
        /// Supplementory Check if the identifier is valid
        /// </summary>
        /// <param name="id">id to check</param>
        /// <returns>true if valid false if not valid</returns>
        private static bool IsValidIdentifier(int id)
        {
            //Need a valid list which is initialized.
            if (!initialized)
            {
                return false;
            }
            //present flag
            bool isPresent = false;
            //iterate to search for the Id
            for (int iterator = 0; iterator < listOfProcesses.Length; iterator++)
            {
                if (listOfProcesses[iterator] != null && listOfProcesses[iterator].ProcessID == id)
                {
                    isPresent = true;
                    //stop if found
                    break;
                }

            }
            //return the falg
            return isPresent;
        }
        /// <summary>
        /// Supplementory function to check the number of processes
        /// </summary>
        /// <returns>number of processes</returns>
        public static int GetListLength()
        {
            //if uninitialized then 0 processes
            if (!initialized)
            {
                return 0;
            }
            int length = 0;
            //iterate and find non null values of indexes which should be valid processes.
            for (int iterator = 0; iterator < listOfProcesses.Length; iterator++)
            {
                if (listOfProcesses[iterator] != null)
                {
                    //increment the number
                    length++;
                }
            }
            //return the length
            return length;
        }

    }
    #endregion
    #region Supplementary classes
    class OperatingSystemProcess
    {
        /// <summary>
        /// Readonly process id makes it immutable after first initialization.
        /// </summary>
        private readonly int processID;
        /// <summary>
        /// Readonly priority immutable after first initialization.
        /// </summary>
        private readonly Priority processPriority;
        /// <summary>
        /// Read only process ID.
        /// </summary>
        public int ProcessID
        {
            get { return processID; }
        }
        /// <summary>
        /// Readonly property for priority
        /// </summary>
        public Priority ProcessPriority
        {
            get { return processPriority; }
        }
        /// <summary>
        /// Creation time immutable
        /// </summary>
        private readonly DateTime creationTime;

        /// <summary>
        /// creation time property readonly.
        /// </summary>
        public DateTime CreationTime
        {
            get { return creationTime; }
        }

        /// <summary>
        /// Constructor to create a process with a priority and ID
        /// </summary>
        /// <param name="priority"></param>
        /// <param name="processID"></param>
        public OperatingSystemProcess(Priority priority, int processID)
        {
            this.processID = processID;
            this.processPriority = priority;
            this.creationTime = DateTime.Now; //Local time
        }
    }

    /// <summary>
    /// Class to maintain a unique identifier
    /// </summary>
    class UniqueIdentifier
    {
        /// <summary>
        /// Set the counter to 1 since identifiers start with 1.
        /// </summary>
        private static int counter = 1;
        /// <summary>
        /// Get the last identifier
        /// </summary>
        /// <returns></returns>
        public static int GetLastIdentifier()
        {
            //the counter is the unique identifier
            return counter;
        }
        /// <summary>
        /// Increment the identifier by 1 for the next time.
        /// </summary>
        public static void Increment()
        {
            counter++;
        }
    }
    /// <summary>
    /// Dummy class to mimic OS process handle.
    /// </summary>
    class OperatingSystemWrapper
    {
        /// <summary>
        /// Dummy method to trigger the actual OS process add operation.
        /// </summary>
        /// <returns>result of the operation</returns>
        public static bool AddProcess()
        {
            return true;
        }
        /// <summary>
        /// Dummy method to trigger the actual OS kill operation.
        /// </summary>
        /// <returns>result of the kill operation</returns>
        public static bool DeleteProcess()
        {
            return true;
        }

    }
    #endregion
    #region User Interface
    class Program
    {
        /// <summary>
        /// The Main entry point of the UI program
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //String holding user input through console.
            string userInput = string.Empty;
            //Write on the colsole - The configurable welcome message.
            Console.WriteLine(System.Configuration.ConfigurationManager.AppSettings["Welcome"]);
            //Console.WriteLine(Properties.Resources.ResourceManager.GetString("Welcome").Trim());
            //Read the configurable capacity.
            string capacity = System.Configuration.ConfigurationManager.AppSettings["Capacity"].Trim();
            //Try to initialize the Task Manager's process list with the capacity.
            Status initializationStatus = TaskManager.Initialize(capacity);
            //If the capacity does not parse into a valid integer
            if (initializationStatus == Status.InvalidCapacity)
            {
                //Print the valid capacity message end exit
                Console.WriteLine(System.Configuration.ConfigurationManager.AppSettings["ValidCapacity"].Trim());
                Environment.Exit(0);
            }
            else if (initializationStatus == Status.Overflow)//if there is an exception because of the framework's limitation of max Array capacity
            {
                //Print the message to suggest user to lower the capacity setting.
                Console.WriteLine(System.Configuration.ConfigurationManager.AppSettings["LowerCapacity"].Trim());
                Environment.Exit(0);
            }
            //Start the recursive UI thread which can be ternimated with certain configurable ExitTocken
            while (userInput != System.Configuration.ConfigurationManager.AppSettings["ExitTocken"].Trim())
            {
                //Check if the user input is a valid action
                if (!IsValidTocken(userInput, UserActions.Add))//The second argument just needs a valid Enumerator. The .Add is just to make it valid does not mean literally.
                {
                    //Write all options of User Action
                    WriteOptions("actions", UserActions.Add);
                    userInput = Console.ReadLine();
                }

                //If user input is valid action
                if (IsValidTocken(userInput.Trim(), UserActions.Add))
                {
                    UserActions action = (UserActions)Enum.Parse(typeof(UserActions), userInput.Trim());

                    //Selector for user action
                    switch (action)
                    {
                        //case Add process
                        case UserActions.Add:
                            //Write options for priority
                            WriteOptions("Priority", Priority.High);
                            string userSelection = Console.ReadLine();
                            //If valid priority
                            if (IsValidTocken(userSelection.Trim(), Priority.High))
                            {
                                Status status;
                                //Call the AddProcess of Task Manager with the priority.
                                status = TaskManager.AddProcess((Priority)Enum.Parse(typeof(Priority), userSelection.Trim()));
                                Console.WriteLine(status);
                            }
                            else
                            {
                                //Not a valid priority
                                PrintInvalidInputMessage(userSelection);
                            }
                            //Reset the user input string for next iteration
                            userInput = string.Empty;
                            //Continue the next iteration.
                            break;
                        //To list the processes
                        case UserActions.List:
                            int counter = 0;
                            //Call the ListProcess of Task Manager.
                            OperatingSystemProcess[] osp = TaskManager.ListProcess();
                            //Find the size of the process list.
                            for (int iterator = 0; iterator < osp.Length; iterator++)
                            {
                                if (osp[iterator] != null)
                                {
                                    //Write the Process ID, Priority and Creation Time for each process
                                    Console.WriteLine(osp[iterator].ProcessID + "|" + osp[iterator].ProcessPriority + "|" + osp[iterator].CreationTime);
                                    counter++;
                                }
                            }
                            Console.WriteLine(string.Format("Total: {0} process/es", counter.ToString()));
                            //Reset the user input for next iteration.
                            userInput = string.Empty;
                            //Continue the next iteration.
                            break;
                        //Sort the list of processes
                        case UserActions.Sort:
                            //If the list of processes is empty then do not proceed.
                            if (TaskManager.GetListLength() == 0)
                            {
                                Console.WriteLine(Status.NoOperation);
                                userInput = string.Empty;
                                break;
                            }
                            //Write the sort basis choices Ex. Priority, Creation Time or Identifier
                            WriteOptions("sort keys", SortBasis.Identifier);
                            string basis = Console.ReadLine();
                            //if the user input is valid
                            if (IsValidTocken(basis.Trim(), SortBasis.Identifier))
                            {
                                //Get the sort basis from user input
                                SortBasis sortBasis = (SortBasis)Enum.Parse(typeof(SortBasis), basis.Trim());
                                //Selector for Sort basis
                                switch (sortBasis)
                                {
                                    case SortBasis.Priority:
                                        //Sort order Ex. Ascending or descending
                                        WriteOptions("sort order", SortOrder.Ascending);
                                        string sortOrder = Console.ReadLine();
                                        //If valid sort order
                                        if (IsValidTocken(sortOrder.Trim(), SortOrder.Ascending))
                                        {
                                            //Fetch the sort order from the user input
                                            SortOrder sortOrderValue = (SortOrder)Enum.Parse(typeof(SortOrder), sortOrder.Trim());
                                            //Call the SortProcess of Task Manager and write its output through WriteSortedProcesses helper method.
                                            WriteSortedProcesses(TaskManager.SortProcesses(sortBasis, sortOrderValue));
                                        }
                                        else
                                        {
                                            //If user input is invalid.
                                            PrintInvalidInputMessage(basis);
                                        }
                                        //Continue for the next iteration.
                                        break;
                                    //Sort by Creation Time.
                                    case SortBasis.CreationTime:
                                        //Write the available sort Order.
                                        WriteOptions("sort order", SortOrder.Ascending);
                                        string sortOrderTime = Console.ReadLine();

                                        //If the sort order is valid
                                        if (IsValidTocken(sortOrderTime.Trim(), SortOrder.Ascending))
                                        {
                                            //Fetch the enum value
                                            SortOrder sortOrderTimeValue = (SortOrder)Enum.Parse(typeof(SortOrder), sortOrderTime.Trim());
                                            //Call the Sort process of task manager and write on console using helper method.
                                            WriteSortedProcesses(TaskManager.SortProcesses(sortBasis, sortOrderTimeValue));
                                        }
                                        else
                                        {
                                            //Invalid user input
                                            PrintInvalidInputMessage(basis);
                                        }
                                        //Continue for next iteration
                                        break;

                                    //Sort by Identifier
                                    case SortBasis.Identifier:
                                        //Write the available sort orders
                                        WriteOptions("sort order", SortOrder.Ascending);
                                        string sortOrderIdentifier = Console.ReadLine();
                                        //if valid sort order eg. Ascending or descending.
                                        if (IsValidTocken(sortOrderIdentifier.Trim(), SortOrder.Ascending))
                                        {
                                            //Fetch the Enum value
                                            SortOrder sortOrderIdentifierValue = (SortOrder)Enum.Parse(typeof(SortOrder), sortOrderIdentifier.Trim());
                                            //Write the output of Task Manager's SortProcesses with the helper method.
                                            WriteSortedProcesses(TaskManager.SortProcesses(sortBasis, sortOrderIdentifierValue));
                                        }
                                        else
                                        {
                                            //Invalid choice.
                                            PrintInvalidInputMessage(basis);
                                        }

                                        break;
                                }
                            }
                            else
                            {
                                //Invalid user choice
                                PrintInvalidInputMessage(basis);
                            }
                            //Clear user input for next iteration.
                            userInput = string.Empty;
                            //Continue for the next iteration.
                            break;
                        //Kill process
                        case UserActions.Kill:

                            //If there are no processes to kill
                            if (TaskManager.GetListLength() == 0)
                            {
                                Console.WriteLine(Status.NoOperation);
                                userInput = string.Empty;
                                break;
                            }

                            //request user input for the process identifier to kill
                            Console.WriteLine(System.Configuration.ConfigurationManager.AppSettings["ProcessIdforKill"].Trim());
                            //receive use input
                            string processID = Console.ReadLine();
                            //Numeric process ID converted from input string
                            int processIDNumeric = 0;
                            if (int.TryParse(processID.Trim(), out processIDNumeric))
                            {
                                //Try to kill the proess by calling TaskManager.KillProcess and write the status.
                                Status status = TaskManager.KillProcess(processIDNumeric);
                                Console.WriteLine(status);
                            }
                            else
                            {
                                //Invalid ID in case of non numeric ID
                                Console.WriteLine(System.Configuration.ConfigurationManager.AppSettings["InvalidID"].Trim());
                            }
                            //Clear the user input for next iteration.
                            userInput = string.Empty;
                            //Continue to next iteration.
                            break;
                        //Kill All
                        case UserActions.KillAll:
                            //Call task Manager's kill All process 
                            Status deleteAllStatus = TaskManager.KillAllProcesses();
                            //Write the status
                            Console.WriteLine(deleteAllStatus);
                            //Clear the user input
                            userInput = string.Empty;
                            //Exit and continue to next iteration.
                            break;
                        //Kill With priority
                        case UserActions.KillWithPriority:
                            //If no processes to kill just return.
                            if (TaskManager.GetListLength() == 0)
                            {
                                Console.WriteLine(Status.NoOperation);
                                userInput = string.Empty;
                                break;
                            }
                            //Status initiated with worst case
                            Status deleteWithPriorityStatus = Status.Error;
                            //Write options for priority
                            WriteOptions("Priority", Priority.High);
                            string priorityToDelete = Console.ReadLine();
                            //If use input is valid priority
                            if (IsValidTocken(priorityToDelete.Trim(), Priority.High))
                            {
                                //Fetch priority value
                                Priority priorityValue = (Priority)Enum.Parse(typeof(Priority), priorityToDelete.Trim());
                                //Call the Task Manager Kill Process overload with priority value
                                deleteWithPriorityStatus = TaskManager.KillProcess(priorityValue);
                            }
                            else
                            {
                                //Invalid user input
                                PrintInvalidInputMessage(priorityToDelete);
                            }

                            //Write the status of the kill operation.
                            Console.WriteLine(deleteWithPriorityStatus);
                            userInput = string.Empty;
                            break;
                        //Add new process in place of the oldest process in case of overlap
                        case UserActions.AddFIFO:
                            //Write priority list
                            WriteOptions("Priority", Priority.High);
                            //Read user input
                            string userSelectionFIFO = Console.ReadLine();
                            //If the input is valid
                            if (IsValidTocken(userSelectionFIFO.Trim(), Priority.High))
                            {
                                Status status;
                                //Call the Task Manager's FIFO method and record the status
                                status = TaskManager.AddProcessFirstInFirstOut((Priority)Enum.Parse(typeof(Priority), userSelectionFIFO.Trim()));

                                Console.WriteLine(status);
                            }
                            else
                            {
                                //Invalid user input
                                PrintInvalidInputMessage(userSelectionFIFO);
                            }
                            userInput = string.Empty;
                            break;
                        //AddProcessHigherPriority
                        case UserActions.AddKeepHigherPriority:
                            //Write options of priority
                            WriteOptions("Priority", Priority.High);
                            //Read user input
                            string userSelectionHighPrio = Console.ReadLine();
                            //If valid user input
                            if (IsValidTocken(userSelectionHighPrio.Trim(), Priority.High))
                            {
                                Status status;
                                //Call the HighPririty method of TaskManager
                                status = TaskManager.AddProcessHigherPriority((Priority)Enum.Parse(typeof(Priority), userSelectionHighPrio.Trim()));
                                Console.WriteLine(status);
                            }
                            else
                            {
                                //Invalid input
                                PrintInvalidInputMessage(userSelectionHighPrio);
                            }
                            userInput = string.Empty;
                            break;
                        case UserActions.Exit:
                            //If user inputs Exit
                            userInput = System.Configuration.ConfigurationManager.AppSettings["ExitTocken"].ToString();
                            break;
                    }
                }
                else
                {
                    //Invalid input
                    PrintInvalidInputMessage(userInput);
                }

            }

        }

        /// <summary>
        /// Checks if the user input is valid against the type of request
        /// </summary>
        /// <param name="tocken"></param>
        /// <param name="enumType"></param>
        /// <returns>true if valid</returns>
        private static bool IsValidTocken(string tocken, Enum enumType)
        {
            //Get the list of enum values of the enum type
            var actionList = Enum.GetValues(enumType.GetType());
            //Iterate the enum values and find match
            foreach (var item in actionList)
            {
                if (tocken == item.ToString())
                {
                    //found match
                    return true;
                }
            }
            //No match fould
            return false;
        }

        /// <summary>
        /// Write to the console all the possible values for a particular action.
        /// </summary>
        /// <param name="optionType">Ex.Priority, Order</param>
        /// <param name="enumType">Ex.Status</param>
        private static void WriteOptions(string optionType, Enum enumType)
        {
            //Get the values of the enum
            var optionList = Enum.GetValues(enumType.GetType());
            System.Text.StringBuilder optionTypes = new System.Text.StringBuilder();
            Console.WriteLine("Please enter one of the following " + optionType + " Case Sensitive!!");
            //hold all the values semicolon seperated.
            foreach (var item in optionList)
            {
                optionTypes.Append(item);
                optionTypes.Append(";");
            }
            //Print the string of options.
            Console.WriteLine(optionTypes.ToString().Remove(optionTypes.Length - 1, 1));
        }

        /// <summary>
        /// Write Invalid input message
        /// </summary>
        /// <param name="input">the provided input</param>
        private static void PrintInvalidInputMessage(string input)
        {
            Console.WriteLine(input + ": Is not a valid input. Hit enter / return to continue");
        }

        /// <summary>
        /// Iterated through the sorted array and print the values in sequence.
        /// </summary>
        /// <param name="processList"></param>
        private static void WriteSortedProcesses(OperatingSystemProcess[] processList)
        {
            for (int iterator = 0; iterator < processList.Length; iterator++)
            {
                if (processList[iterator] != null)
                {
                    Console.WriteLine(processList[iterator].ProcessID + "|" + processList[iterator].ProcessPriority + "|" + processList[iterator].CreationTime);
                }
            }

        }

    }
    #endregion
    #region Enumerators
    public enum Status { Overflow, Success, Error, Invalid, InvalidCapacity, NoOperation };
    public enum SortBasis { Identifier, CreationTime, Priority };
    public enum UserActions { Add, AddFIFO, AddKeepHigherPriority, List, Sort, Kill, KillWithPriority, KillAll, Exit };
    public enum SortOrder { Ascending, Descending };
    public enum Priority { Low, Medium, High };
    #endregion
    #region Custom Comparators
    /// <summary>
    /// Compares the process creation dates in ascending order.
    /// </summary>
    class ProcessComparerByDateAsc : Comparer<OperatingSystemProcess>
    {
        public override int Compare(OperatingSystemProcess param1, OperatingSystemProcess param2)
        {
            if (param1 != null && param2 != null)
                return param1.CreationTime.CompareTo(param2.CreationTime);
            else
                return 0;
        }
    }
    /// <summary>
    /// Compares the process creation dates in descending order
    /// </summary>
    class ProcessComparerByDateDesc : Comparer<OperatingSystemProcess>
    {
        public override int Compare(OperatingSystemProcess param1, OperatingSystemProcess param2)
        {
            if (param1 != null && param2 != null)
            {
                if (param1.CreationTime.CompareTo(param2.CreationTime) < 0)
                    return 1;
                else if (param1.CreationTime.CompareTo(param2.CreationTime) > 0)
                    return -1;
                else
                    return 0;
            }
            else
                return 0;
        }
    }
    /// <summary>
    /// Compares process priority in descending order
    /// </summary>
    class ProcessCompareByPriorityDesc : Comparer<OperatingSystemProcess>
    {
        public override int Compare([AllowNull] OperatingSystemProcess param1, [AllowNull] OperatingSystemProcess param2)
        {


            if (param1 != null && param2 != null)
            {
                if (param1.ProcessPriority == Priority.High && param2.ProcessPriority == Priority.Medium)
                    return -1;
                else
                if (param1.ProcessPriority == Priority.High && param2.ProcessPriority == Priority.Low)
                    return -1;
                else
                if (param1.ProcessPriority == Priority.Medium && param2.ProcessPriority == Priority.Low)
                    return -1;
                else
                if (param1.ProcessPriority == Priority.Low && param2.ProcessPriority == Priority.High)
                    return 1;
                else
                if (param1.ProcessPriority == Priority.Medium && param2.ProcessPriority == Priority.High)
                    return 1;
                if (param1.ProcessPriority == Priority.Low && param2.ProcessPriority == Priority.Medium)
                    return 1;
                else
                    return 0;
            }
            else return 0;
        }
    }
    /// <summary>
    /// Compares Process Priorities in Ascending order
    /// </summary>
    class ProcessCompareByPriorityAsc : Comparer<OperatingSystemProcess>
    {
        public override int Compare([AllowNull] OperatingSystemProcess param1, [AllowNull] OperatingSystemProcess param2)
        {


            if (param1 != null && param2 != null)
            {
                if (param1.ProcessPriority == Priority.High && param2.ProcessPriority == Priority.Medium)
                    return 1;
                else
                if (param1.ProcessPriority == Priority.High && param2.ProcessPriority == Priority.Low)
                    return 1;
                else
                if (param1.ProcessPriority == Priority.Medium && param2.ProcessPriority == Priority.Low)
                    return 1;
                else
                if (param1.ProcessPriority == Priority.Low && param2.ProcessPriority == Priority.High)
                    return -1;
                else
                if (param1.ProcessPriority == Priority.Medium && param2.ProcessPriority == Priority.High)
                    return -1;
                if (param1.ProcessPriority == Priority.Low && param2.ProcessPriority == Priority.Medium)
                    return -1;
                else
                    return 0;
            }
            else return 0;
        }
    }
    /// <summary>
    /// Compares process identifiers by ascending order
    /// </summary>
    class ProcessComparerByIdentifierAsc : Comparer<OperatingSystemProcess>
    {
        public override int Compare(OperatingSystemProcess param1, OperatingSystemProcess param2)
        {
            if (param1 != null && param2 != null)
            {
                if (param1.ProcessID > param2.ProcessID)
                    return 1;
                else
            if (param1.ProcessID < param2.ProcessID)
                    return -1;
                else
                    return 0;
            }
            else return 0;
        }
    }
    /// <summary>
    /// Compares process identifiers in descending order
    /// </summary>
    class ProcessComparerByIdentifierDesc : Comparer<OperatingSystemProcess>
    {
        public override int Compare(OperatingSystemProcess param1, OperatingSystemProcess param2)
        {
            if (param1 != null && param2 != null)
            {
                if (param1.ProcessID > param2.ProcessID)
                    return -1;
                else
            if (param1.ProcessID < param2.ProcessID)
                    return 1;
                else
                    return 0;
            }
            else return 0;
        }
    }

    /// <summary>
    /// Compares the priority of two processes and returns integer value 
    /// </summary>
    class PrioritiesComparer
    {
        public static int Compare(Priority priority1, Priority priority2)
        {

            if (priority1 == Priority.High && priority2 == Priority.Medium)
                return 1;
            else
            if (priority1 == Priority.High && priority2 == Priority.Low)
                return 1;
            else
            if (priority1 == Priority.Medium && priority2 == Priority.Low)
                return 1;
            else
            if (priority1 == Priority.Low && priority2 == Priority.High)
                return -1;
            else
            if (priority1 == Priority.Medium && priority2 == Priority.High)
                return -1;
            if (priority1 == Priority.Low && priority2 == Priority.Medium)
                return -1;
            else
                return 0;
        }
    }
    #endregion
}
